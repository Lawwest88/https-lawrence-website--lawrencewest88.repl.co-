var x=4;
var array= [1,2,3,10,88,45];
var fruits = ["Banana", "Orange", "Apple", "Mango"];
console.log(fruits.length);
console.log (array)
console.log (fruits);
// console.log (fruits[0]);
// console.log (fruits[1]);
// console.log (fruits[2]);
// console.log (fruits[3]);
console.log (fruits[0],fruits[1],fruits[2]);

//create array with the languager in the course.
var lang= ["HTML","CSS","JS"];
// the lenght of the array: 
// var lenghtOfArray=lang.length;
// console.log(lenghtOfArray);
// for(i=0; i<lenghtOfArray; i++){
//   console.log(lang[i]);
// }

var text="";
for (i=0; i<lang.lenth; i++){
  text +=lang[i]+"<br>";
}

document.getElementById("demo").innerHTML=text;

var cars=["BMW", "Volvo","Saab","Ford","Fiat", "Audi"];

document.getElementById("forLenght").innerHTML=cars.length;